var onShowHtml = "";
var onFocusHtml = "<span class='$class$'>$data$</span>";
var onErrorHtml = "<div class='$class$'><div class='$class$-bottom'><div class='$class$-right'><div class='$class$-left'><p class='$class$-top-right'>$data$</p></div></div></div></div>"
var onCorrectHtml = "<span class='$class$'></span>";
var onShowClass = "input_public";
var onFocusClass = "input_public input_focus";
var onErrorClass = "input_public input_error";
var onCorrectClass = "input_public input_correct";