var onShowHtml = "<div class='$class$'>$data$</div>";
var onFocusHtml = "<div class='$class$'>$data$</div>";
var onErrorHtml = "<div class='$class$'>$data$</div>";
var onCorrectHtml = "<div class='$class$'>$data$</div>";
var onShowClass = "";
var onFocusClass = "";
var onErrorClass = "";
var onCorrectClass = "";